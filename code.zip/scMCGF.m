
clc;  close all; clear all;
currentFolder = pwd;
addpath(genpath(currentFolder));
resultdir = 'Results/';
if(~exist('Results','file'))
    mkdir('Results');
    addpath(genpath('Results/'));
end

tic 
data_select='n10X_muscle_2000'; 
switch data_select
         case 'n10X_muscle_2000'
         load n10X_muscle_2000.txt
         load n10X_muscle_truelabel.csv
         load n10X_muscle_mat_path.csv
         True_lab=n10X_muscle_truelabel';
         input_Seq=n10X_muscle_2000; 
         input_mat_path=n10X_muscle_mat_path; 
end  
no_dims=round(intrinsic_dim(input_Seq,'MLE'));
mappeA = compute_mapping(input_Seq,'DiffusionMaps',no_dims);
mappeB = compute_mapping(input_Seq,'PCA',no_dims);
mappeC=input_Seq;
 input_Seq1=mappeA';
 input_Seq2=mappeB';
 input_Seq3=input_mat_path;
 input_Seq4=mappeC';
 clear mappeA mappeB mappeC input_mat_path 
 data{1,1}=input_Seq1;
 data{1,2}=input_Seq2;
 data{1,3}=input_Seq3;
 data{1,4}=input_Seq4;
 truelabel{1,1}=True_lab;
 truelabel{1,2}=True_lab;
 truelabel{1,3}=True_lab;
 save(['J:\E19101006\scMCGF\',data_select],'data','truelabel');
 clear input_Seq1 input_Seq2 input_Seq3 input_Seq4 data
dataname ={data_select}; 
runtimes = 1;
numdata = length(dataname);

for cdata = 1:numdata
idata = cdata;
datadir = 'J:\E19101006\scMCGF\';
dataf = [datadir, cell2mat(dataname(idata))];
load(dataf);
X = data;
y0 = truelabel{1};
c = length(unique(truelabel{1}));
for rtimes = 1:runtimes
    [y, U, S0, S0_initial, F, evs] = GMC(X, c); 
     y_lable=y;
metric = CalcMeasures(y0, y);
ACC(rtimes) = metric(1);
NMI(rtimes) = metric(2);
ARI(rtimes) = metric(3);
error_cnt(rtimes) = metric(4);
disp(char(dataname(idata)));
fprintf('=====In iteration %d=====\nACC:%.4f\tNMI:%.4f\tARI:%.4f\terror_cnt:%d\n',rtimes,metric(1),metric(2),metric(3),metric(4));
end;
    Result(1,:) = ACC;
    Result(2,:) = NMI;
    Result(3,:) = ARI;
    Result(4,1) = mean(ACC);
    Result(4,2) = mean(NMI);
    Result(4,3) = mean(ARI);
    Result(5,1) = std(ACC);
    Result(5,2) = std(NMI);
    Result(5,3) = std(ARI);
save([resultdir,char(dataname(idata)),'_result.mat'],'Result','U','y0','y');
mytimer1=toc; 
disp(mytimer1)
clear ACC NMI ARI metric Result U y0 y;
end;
